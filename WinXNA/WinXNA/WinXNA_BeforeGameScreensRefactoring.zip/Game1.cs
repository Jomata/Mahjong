using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Mahjong;
using Mahjong.Async.Players;

namespace MahjongXNA
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        private static int Margin = 10;
        private static int TilesPerDiscardRow = 6;

        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Mahjong.Async.Game MJGame;
        HmnXNA Player;
        SpriteFont Font_CourierNew;

        Color SelectableTileColor_Highlighted = Color.LightPink;
        Color SelectableTileColor_MouseOver = Color.DeepPink;
        Color SelectableTileColor_RiichiDiscard = Color.HotPink;
        Color SelectableTileColor_Recommended = Color.HotPink;
        bool recommendDiscards = true;
        bool tileToolTips = true;

        Dictionary<Mahjong.IPlayer, BoardPosition> PlayerPositions;

        IDictionary<string, Texture2D> TileTextures = new Dictionary<string, Texture2D>(9*3+4+3);
        Dictionary<string, List<Tile>> RecommendedTilesCache = new Dictionary<string, List<Tile>>();
        Dictionary<string, int> ShantenCahe = new Dictionary<string, int>();
        Texture2D BackTileTexture;
        

        List<TileTextureInfo> TilesToDraw = new List<TileTextureInfo>();

        Vector2 tooltipPosition = Vector2.Zero;
        string tooltipText = String.Empty;
        Texture2D tooltipBG;
        Color tooltipBGColor = Color.Gold;

        private Point MousePosition
        {
            get
            {
                var mouseState = Mouse.GetState();
                var mousePosition = new Point(mouseState.X, mouseState.Y);
                return mousePosition;
            }
        }

        private void LoadTileTextures()
        {
            var allTiles = Tile.GetAllTiles();
            foreach (var tile in allTiles)
            {
                if(!TileTextures.ContainsKey(tile.ToString()))
                    TileTextures.Add(tile.ToString(),Content.Load<Texture2D>(tile.GetTexturePath()));
            }
            BackTileTexture =  Content.Load<Texture2D>(Tile.Unknown().GetTexturePath());
        }

        private Vector2 TopCenter { get { return new Vector2(GraphicsDevice.Viewport.Width / 2 , 0); } }
        private Vector2 BotCenter { get { return new Vector2(GraphicsDevice.Viewport.Width / 2, GraphicsDevice.Viewport.Height); } }
        private Vector2 LeftCenter { get { return new Vector2(0, GraphicsDevice.Viewport.Height / 2); } }
        private Vector2 RightCenter { get { return new Vector2(GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height / 2); } }

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            graphics.IsFullScreen = false;
            graphics.PreferredBackBufferHeight = 700;
            graphics.PreferredBackBufferWidth = 850;
            this.Window.Title = "XNA Mahjong";
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            IsMouseVisible = true;

            this.Player = new HmnXNA();
            this.Player.Name = "Human";

            this.MJGame = new Mahjong.Async.Game();
            this.MJGame.RegisterPlayer(this.Player);
            this.MJGame.RegisterPlayer(new AIFirst { Name = "First" });
            this.MJGame.RegisterPlayer(new AIFirst { Name = "Nope" });
            this.MJGame.RegisterPlayer(new AIFirst { Name = "Shan" });

            this.MJGame.Play();

            this.PlayerPositions = new Dictionary<IPlayer, BoardPosition>();
            this.PlayerPositions.Add(this.Player, BoardPosition.Bot);
            var currPlayer = this.MJGame.GetPlayerAfter(this.Player);
            this.PlayerPositions.Add(currPlayer, BoardPosition.Left);
            currPlayer = this.MJGame.GetPlayerAfter(currPlayer);
            this.PlayerPositions.Add(currPlayer, BoardPosition.Top);
            currPlayer = this.MJGame.GetPlayerAfter(currPlayer);
            this.PlayerPositions.Add(currPlayer,BoardPosition.Right);

            #region Loading Config info
            this.SelectableTileColor_Highlighted = Colors.FromName(GetConfigValue("SelectableTileColor_Highlighted"));
            this.SelectableTileColor_MouseOver = Colors.FromName(GetConfigValue("SelectableTileColor_MouseOver"));
            this.SelectableTileColor_RiichiDiscard = Colors.FromName(GetConfigValue("SelectableTileColor_RiichiDiscard"));
            this.SelectableTileColor_Recommended = Colors.FromName(GetConfigValue("SelectableTileColor_Recommended"));
            bool.TryParse(GetConfigValue("recommendDiscards"), out this.recommendDiscards);
            bool.TryParse(GetConfigValue("tileToolTips"), out this.tileToolTips);
            #endregion

            base.Initialize();
        }

        private string GetConfigValue(string key)
        {
            return System.Configuration.ConfigurationSettings.AppSettings[key];
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            LoadTileTextures();
            this.Font_CourierNew = Content.Load<SpriteFont>("CourierNew");

            this.tooltipBG = new Texture2D(this.GraphicsDevice, 1, 1, false, SurfaceFormat.Color);
            this.tooltipBG.SetData<Color>(new Color[] { this.tooltipBGColor });
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        string BoardMessage = "";

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            // TODO: Add your update logic here
            #region Click Observer
            var lastMouseState = currentMouseState;

            // Get the mouse state relevant for this frame
            currentMouseState = Mouse.GetState();

            // Recognize a single click of the left mouse button
            if (this.IsActive)
            {
                if (lastMouseState.LeftButton == ButtonState.Released && currentMouseState.LeftButton == ButtonState.Pressed)
                {
                    this.OnMouseDown(currentMouseState);
                }
                else if (lastMouseState.LeftButton == ButtonState.Pressed && currentMouseState.LeftButton == ButtonState.Released)
                {
                    this.OnMouseUp(currentMouseState);
                }
            }
            #endregion

            this.TilesToDraw.Clear();
            #region Player Tiles
            UpdatePlayerHandTiles(BoardPosition.Bot, this.Player);
            var currPlayer = this.MJGame.GetPlayerAfter(this.Player);
            UpdatePlayerHandTiles(BoardPosition.Left, currPlayer);
            currPlayer = this.MJGame.GetPlayerAfter(currPlayer);
            UpdatePlayerHandTiles(BoardPosition.Top, currPlayer);
            currPlayer = this.MJGame.GetPlayerAfter(currPlayer);
            UpdatePlayerHandTiles(BoardPosition.Right, currPlayer);
            #endregion
            UpdatePlayersDiscardPools();
            UpdateDoras();
            UpdateTooltip(); //Must be called after all tiles are calculated
            BoardMessage = Player.Message;
            if (this.Player.Status == HmnXNAStatus.ChoosingDiscard && this.recommendDiscards)
            {
                if (!String.IsNullOrWhiteSpace(BoardMessage))
                    BoardMessage += "\n";
                BoardMessage += string.Format("Shanten {0}. Recommended discards highlighted.", this.GetShantenNumber(this.Player.MyTiles));
            }

            base.Update(gameTime);
        }

        void UpdateTooltip()
        {
            if (tileToolTips)
            {
                this.tooltipPosition = Vector2.Zero;
                this.tooltipText = String.Empty;

                var hoveredTile = this.TilesToDraw.Find(tti => tti.Tile != null && tti.Rectangle.Contains(MousePosition));
                if (hoveredTile != null)
                {
                    this.tooltipPosition = new Vector2(MousePosition.X+15, MousePosition.Y);
                    this.tooltipText = hoveredTile.Tile.ToLongString();
                }
            }
        }

        void UpdatePlayersDiscardPools()
        {
            foreach (var player in this.MJGame.Players)
            {
                Vector2 discardPoolStart = Vector2.Zero;
                //Vector2 center = new Vector2(this.GraphicsDevice.Viewport.Width / 2, this.GraphicsDevice.Viewport.Height / 2);
                int discardPoolWidth = (TilesPerDiscardRow - 1) * this.BackTileTexture.Width + 1 * this.BackTileTexture.Height; //5 tiles normal, 1 sideway tile for riichi
                int discardPoolHeight = 3 * this.BackTileTexture.Height;
                int paddingUnderDiscardPool = Margin + BackTileTexture.Height + Margin;
                int tileOffsetX = 0, tileOffsetY = 0;
                float angle = 0;
                bool HorizontalTiles = true;

                switch (this.PlayerPositions[player])
                {
                    case BoardPosition.Top:
                        discardPoolStart = TopCenter;
                        discardPoolStart.X += discardPoolWidth / 2;
                        discardPoolStart.Y += paddingUnderDiscardPool + discardPoolHeight;
                        tileOffsetX = -1 * BackTileTexture.Width;
                        tileOffsetY = -1 * BackTileTexture.Height;
                        angle = (float)Math.PI;  // 180 degrees;
                        break;
                    case BoardPosition.Bot:
                        discardPoolStart = BotCenter;
                        discardPoolStart.X -= discardPoolWidth / 2;
                        discardPoolStart.Y -= paddingUnderDiscardPool + discardPoolHeight;
                        tileOffsetX = +1 * BackTileTexture.Width;
                        tileOffsetY = +1 * BackTileTexture.Height;
                        break;
                    case BoardPosition.Left:
                        discardPoolStart = LeftCenter;
                        discardPoolStart.Y += discardPoolWidth / 2;
                        discardPoolStart.X += paddingUnderDiscardPool + discardPoolHeight;
                        discardPoolStart.Y -= BackTileTexture.Height; //compensating for rotation
                        tileOffsetX = -1 * BackTileTexture.Height;
                        tileOffsetY = -1 * BackTileTexture.Width;
                        HorizontalTiles = false;
                        angle = (float)Math.PI / 2.0f;  // 90 degrees
                        break;
                    case BoardPosition.Right:
                        discardPoolStart = RightCenter;
                        discardPoolStart.Y += discardPoolWidth / 2;
                        discardPoolStart.X -= paddingUnderDiscardPool + discardPoolHeight;
                        tileOffsetX = +1 * BackTileTexture.Height;
                        tileOffsetY = -1 * BackTileTexture.Width;
                        HorizontalTiles = false;
                        angle = (float)Math.PI * 1.5f;  // 270 degrees
                        break;
                }

                int i = 0;
                foreach (var discardedTile in player.Discards)
                {
                    var TTI = new TileTextureInfo();
                    TTI.Tile = discardedTile;
                    TTI.Texture = this.TileTextures[discardedTile.ToString()];
                    if (HorizontalTiles)
                        TTI.Position = new Vector2(discardPoolStart.X + (i % TilesPerDiscardRow) * tileOffsetX, discardPoolStart.Y + (i / TilesPerDiscardRow) * tileOffsetY);
                    else
                        TTI.Position = new Vector2(discardPoolStart.X + (i / TilesPerDiscardRow) * tileOffsetX, discardPoolStart.Y + (i % TilesPerDiscardRow) * tileOffsetY);

                    TTI.Rotation = angle;
                    i++;

                    this.TilesToDraw.Add(TTI);
                }
                if (this.Player.Status == HmnXNAStatus.AskingIntercept && this.Player.PlayerDiscardingTile == player)
                {
                    var TTI = new TileTextureInfo();
                    TTI.Tile = this.Player.TileBeingDiscarded;
                    TTI.Texture = this.TileTextures[this.Player.TileBeingDiscarded.ToString()];
                    if (HorizontalTiles)
                        TTI.Position = new Vector2(discardPoolStart.X + (i % TilesPerDiscardRow) * tileOffsetX, discardPoolStart.Y + (i / TilesPerDiscardRow) * tileOffsetY);
                    else
                        TTI.Position = new Vector2(discardPoolStart.X + (i / TilesPerDiscardRow) * tileOffsetX, discardPoolStart.Y + (i % TilesPerDiscardRow) * tileOffsetY);

                    TTI.Rotation = angle;

                    if (TTI.Rectangle.Contains(MousePosition))
                        TTI.ShadeColor = this.SelectableTileColor_MouseOver;
                    //TTI.MouseOvered = true;
                    else
                        TTI.ShadeColor = this.SelectableTileColor_Highlighted;
                        //TTI.Highlighted = true;

                    TTI.Tile = this.Player.TileBeingDiscarded;
                    this.TilesToDraw.Add(TTI);
                }
            }
        }

        /*void UpdatePlayerDiscarding(Mahjong.Async.Player Discarder, Tile Discarded)
        {
            var discardPosition = Vector2.Zero;


            switch (this.PlayerPositions[Discarder])
            {
                case BoardPosition.Top:
                    discardPosition = TopCenter;
                    discardPosition.X -= BackTileTexture.Width/2;
                    discardPosition.Y += Margin + BackTileTexture.Height + Margin;
                    break;
                case BoardPosition.Bot:
                    discardPosition = BotCenter;
                    discardPosition.X -= BackTileTexture.Width/2;
                    discardPosition.Y -= Margin + BackTileTexture.Height + Margin;
                    break;
                case BoardPosition.Left:
                    discardPosition = LeftCenter;
                    discardPosition.X += Margin + BackTileTexture.Height + Margin;
                    discardPosition.Y -= BackTileTexture.Width / 2;
                    break;
                case BoardPosition.Right:
                    discardPosition = RightCenter;
                    discardPosition.X -= Margin + BackTileTexture.Height + Margin + BackTileTexture.Width;
                    discardPosition.Y -= BackTileTexture.Width / 2;
                    break;
            }

            var TTI = new TileTextureInfo();
            TTI.Texture = this.TileTextures[Discarded.ToString()];
            TTI.Tile = Discarded;
            TTI.Position = discardPosition;

            if (this.Player.Status == HmnXNAStatus.AskingIntercept)
            {
                if (TTI.Rectangle.Contains(MousePosition)) TTI.MouseOvered = true;

                TTI.Highlighted = true;
            }

            this.TilesToDraw.Add(TTI);
        }*/

        static string GetTilesKey(IList<Tile> Tiles)
        {
            return String.Join("", Tiles);
        }

        MouseState currentMouseState;
        void OnMouseDown(MouseState e)
        {
        }

        void OnMouseUp(MouseState e)
        {
            var mousePosition = new Point(e.X, e.Y);

            if (this.Player.Status == HmnXNAStatus.AskingIntercept)
            {
                var tileClicked = this.TilesToDraw.Find(tti => tti.Tile != null && tti.Rectangle.Contains(mousePosition));
                if(tileClicked != null)
                    this.Player.TileWasClicked(tileClicked.Tile);
                else
                    this.Player.TileWasClicked(null);

                //bool tileWasClicked = false;
                //foreach (var TTI in this.TilesToDraw)
                //{
                //    if (TTI.Highlighted && TTI.MouseOvered)
                //    {
                //        this.Player.TileWasClicked(TTI.Tile);
                //        tileWasClicked = true;
                //        break;
                //    }
                //}
                //if (!tileWasClicked) this.Player.TileWasClicked(null);
            }
            else if (this.Player.Status == HmnXNAStatus.ChoosingDiscard)
            {
                foreach (var TTI in this.TilesToDraw)
                {
                    //if (TTI.Highlighted && TTI.MouseOvered)
                    if(TTI.Rectangle.Contains(mousePosition))
                    {
                        this.Player.TileWasClicked(TTI.Tile);
                        break;
                    }
                }

                //foreach (var tilePosition in this.PlayerTilePositions)
                //{
                //    if (tilePosition.Value.Contains(mousePosition))
                //    {
                //        this.Player.Action_ChooseDiscard(tilePosition.Key);
                //        break;
                //    }
                //}
            }
        }

        private enum BoardPosition { Top, Bot, Left, Right}

        private void UpdatePlayerHandTiles(BoardPosition PlayerPosition, Mahjong.Async.Player currPlayer)
        {
            Vector2 tileListStart = Vector2.Zero;
            Vector2 meldsStart = Vector2.Zero;
            //var scale = 1.0f;
            float angle = 0;
            int tileOffsetX = 0;
            int tileOffsetY = 0;

            var mouseState = Mouse.GetState();
            var mousePosition = new Point(mouseState.X, mouseState.Y);

            switch (PlayerPosition)
            {
                case BoardPosition.Top:
                    tileListStart = this.TopCenter;
                    tileListStart.Y += Margin + BackTileTexture.Height;
                    tileListStart.X += (14 * BackTileTexture.Width) / 2;
                    tileListStart.X -= BackTileTexture.Width;
                    angle = (float)Math.PI;  // 180 degrees;
                    tileOffsetX = -1 * BackTileTexture.Width;
                    tileOffsetY = 0;
                    meldsStart.X = Margin + BackTileTexture.Width;
                    meldsStart.Y = Margin + BackTileTexture.Height;
                    break;
                case BoardPosition.Bot:
                    tileListStart = this.BotCenter;
                    tileListStart.Y -= this.TileTextures.Values.Max(x => x.Height) + Margin;
                    tileListStart.X -= (14 * this.TileTextures.Values.Max(x => x.Width)) / 2;
                    angle = 0;
                    tileOffsetX = this.BackTileTexture.Width;
                    tileOffsetY = 0;
                    meldsStart.X = GraphicsDevice.Viewport.Width - Margin - this.BackTileTexture.Width;
                    meldsStart.Y = GraphicsDevice.Viewport.Height - Margin - this.BackTileTexture.Height;
                    break;
                case BoardPosition.Left:
                    tileListStart = this.LeftCenter;
                    tileListStart.Y -= (14 * BackTileTexture.Width) / 2;
                    tileListStart.Y += BackTileTexture.Width;
                    tileListStart.X += Margin + BackTileTexture.Height;
                    angle = (float)Math.PI / 2.0f;  // 90 degrees
                    tileOffsetX = 0;
                    tileOffsetY = BackTileTexture.Width;
                    meldsStart.X = tileListStart.X;
                    meldsStart.Y = GraphicsDevice.Viewport.Height - Margin - BackTileTexture.Width;
                    break;
                case BoardPosition.Right:
                    tileListStart = this.RightCenter;
                    tileListStart.Y += (14 * BackTileTexture.Width) / 2;
                    tileListStart.X -= Margin + BackTileTexture.Height;
                    tileListStart.Y -= BackTileTexture.Width;
                    angle = (float)Math.PI * 1.5f;  // 270 degrees
                    tileOffsetX = 0;
                    tileOffsetY = -1 * BackTileTexture.Width;
                    meldsStart.X = tileListStart.X;
                    meldsStart.Y = Margin + BackTileTexture.Width;
                    break;
            }

            Vector2 currentPosition = new Vector2(tileListStart.X, tileListStart.Y);
            List<Tile> recommendedTiles = new List<Tile>();
            if (recommendDiscards && this.Player.Status == HmnXNAStatus.ChoosingDiscard)
            {
                recommendedTiles = GetRecommendedDiscards(this.Player.MyTiles);
            }

            if (currPlayer == this.Player)
            {
                int i = 0;
                foreach (var tile in this.Player.MyTiles.OrderBy(t => t.Value()))
                {
                    if (tile != this.Player.LastDraw)
                    {
                        var TTI = new TileTextureInfo();
                        
                        TTI.Tile = tile;

                        TTI.Texture = this.TileTextures[tile.ToString()];
                        TTI.Position = currentPosition;
                        TTI.Rotation = angle;
                        
                        if (this.Player.Status == HmnXNAStatus.ChoosingDiscard)
                        {
                            if (TTI.Rectangle.Contains(mousePosition))
                            {
                                TTI.ShadeColor = this.SelectableTileColor_MouseOver;
                            }
                            else if (recommendDiscards && recommendedTiles.Contains(TTI.Tile))
                            {
                                TTI.ShadeColor = this.SelectableTileColor_Recommended;
                            }
                            else
                            {
                                TTI.ShadeColor = this.SelectableTileColor_Highlighted;
                            }
                        }
                        else if (this.Player.Status == HmnXNAStatus.AskingRiichi)
                        {
                            if (this.Player.riichiDiscardTiles.Contains(TTI.Tile))
                            {
                                if (TTI.Rectangle.Contains(mousePosition))
                                    TTI.ShadeColor = this.SelectableTileColor_MouseOver;
                                else
                                    TTI.ShadeColor = this.SelectableTileColor_RiichiDiscard;
                            }
                        }

                        currentPosition.X += tileOffsetX;
                        currentPosition.Y += tileOffsetY;

                        i++;

                        this.TilesToDraw.Add(TTI);
                    }
                }

                //most recent tile always at the end
                if (this.Player.LastDraw != null)
                {
                    var TTI = new TileTextureInfo();

                    TTI.Tile = this.Player.LastDraw;

                    TTI.Texture = this.TileTextures[this.Player.LastDraw.ToString()];
                    TTI.Position = currentPosition;
                    TTI.Rotation = angle;
                    //TTI.Rectangle = new Rectangle(
                    //    (int)currentPosition.X,
                    //    (int)currentPosition.Y,
                    //    BackTileTexture.Width, BackTileTexture.Height);

                    if (this.Player.Status == HmnXNAStatus.ChoosingDiscard)
                    {
                        if (TTI.Rectangle.Contains(mousePosition))
                            TTI.ShadeColor = this.SelectableTileColor_MouseOver;
                        //TTI.MouseOvered = true;
                        else
                            TTI.ShadeColor = this.SelectableTileColor_Highlighted;
                        //TTI.Highlighted = true;
                    }

                    currentPosition.X += tileOffsetX;
                    currentPosition.Y += tileOffsetY;

                    this.TilesToDraw.Add(TTI);
                }
            }
            else
            {
                for (int i = 0; i < currPlayer.HandTilesCount; i++)
                {
                    var TTI = new TileTextureInfo();
                    TTI.Texture = this.BackTileTexture;
                    TTI.Position = currentPosition;
                    TTI.Rotation = angle;
                    //TTI.Rectangle = new Rectangle(
                    //    (int)currentPosition.X,
                    //    (int)currentPosition.Y,
                    //    BackTileTexture.Width, BackTileTexture.Height);

                    currentPosition.X += tileOffsetX;
                    currentPosition.Y += tileOffsetY;

                    this.TilesToDraw.Add(TTI);
                }
            }

            currentPosition = meldsStart;
            foreach (var meld in currPlayer.ExposedMelds)
            {
                foreach (var meldTile in meld.Tiles.OrderBy(x => x.Value() * -1))
                {
                    //currentPosition.X -= tileOffsetX;
                    //currentPosition.Y -= tileOffsetY;

                    var TTI = new TileTextureInfo();
                    TTI.Tile = meldTile;
                    TTI.Texture = TileTextures[meldTile.ToString()];
                    TTI.Position = currentPosition;
                    TTI.Rotation = angle;
                    //TTI.Rectangle = new Rectangle(
                    //    (int)currentPosition.X,
                    //    (int)currentPosition.Y,
                    //    BackTileTexture.Width, BackTileTexture.Height);

                    currentPosition.X -= tileOffsetX;
                    currentPosition.Y -= tileOffsetY;

                    this.TilesToDraw.Add(TTI);
                }
            }

            //if (this.PlayerTiles.ContainsKey(PlayerPosition)) this.PlayerTiles[PlayerPosition] = TileTextureInfoList;
            //else this.PlayerTiles.Add(PlayerPosition, TileTextureInfoList);
        }

        private List<Tile> GetRecommendedDiscards(IList<Tile> Hand)
        {
            List<Tile> recommendedTiles = new List<Tile>();
            var cacheKey = GetTilesKey(this.Player.MyTiles);
            if (this.RecommendedTilesCache.ContainsKey(cacheKey))
            {
                recommendedTiles = this.RecommendedTilesCache[cacheKey];
            }
            else
            {
                var shantenInfo = this.Player.GetShantenInfo();
                recommendedTiles = shantenInfo.Value;
                this.RecommendedTilesCache.Add(cacheKey, recommendedTiles);
                this.ShantenCahe.Add(cacheKey, shantenInfo.Key);
            }
            return recommendedTiles;
        }

        private int GetShantenNumber(IList<Tile> Hand)
        {
            List<Tile> recommendedTiles = new List<Tile>();
            var cacheKey = GetTilesKey(this.Player.MyTiles);
            if (!this.ShantenCahe.ContainsKey(cacheKey))
            {
                var shantenInfo = this.Player.GetShantenInfo();
                this.RecommendedTilesCache.Add(cacheKey, shantenInfo.Value);
                this.ShantenCahe.Add(cacheKey, shantenInfo.Key);
            }

            return ShantenCahe[cacheKey];
        }

        private void UpdateDoras()
        {
            //Center, 5tiles wide, 2 tiles tall
            Vector2 center = new Vector2(this.GraphicsDevice.Viewport.Width/2, this.GraphicsDevice.Viewport.Height/2);

            var wallHeight = 2 * this.BackTileTexture.Height;
            var wallWidth = 5 * this.BackTileTexture.Width;

            Vector2 deadWallPosition = Vector2.Zero;
            deadWallPosition.X = center.X - wallWidth / 2;
            deadWallPosition.Y = center.Y;

            for (int i = 0; i < 5; i++)
            {
                Texture2D top, bot;
                TileTextureInfo ttiBot = new TileTextureInfo();
                TileTextureInfo ttiTop = new TileTextureInfo();

                if (MJGame.DoraIndicators.Count > i)
                {
                    top = this.TileTextures[MJGame.DoraIndicators[i].ToString()];
                    ttiTop.Tile = MJGame.DoraIndicators[i];
                }
                else
                {
                    top = this.BackTileTexture;
                }
                if (MJGame.UradoraIndicators.Count > i)
                {
                    bot = this.TileTextures[MJGame.UradoraIndicators[i].ToString()];
                    ttiBot.Tile = MJGame.UradoraIndicators[i];
                }
                else
                {
                    bot = this.BackTileTexture;
                }

                //spriteBatch.Draw(bot, deadWallPosition, Color.White);
                ttiBot.Position = deadWallPosition;
                ttiBot.Texture = bot;
                deadWallPosition.Y -= bot.Height;
                //spriteBatch.Draw(top, deadWallPosition, Color.White);
                ttiTop.Position = deadWallPosition;
                ttiTop.Texture = top;

                deadWallPosition.X += top.Width;
                deadWallPosition.Y += bot.Height;

                TilesToDraw.Add(ttiBot);
                TilesToDraw.Add(ttiTop);
            }
        }

        private void DrawMessage()
        {
            if (!String.IsNullOrWhiteSpace(BoardMessage))
            {
                Vector2 messagePosition = Vector2.Zero;
                var stringSize = this.Font_CourierNew.MeasureString(BoardMessage);
                messagePosition.X = (this.GraphicsDevice.Viewport.Width - stringSize.X) / 2;
                messagePosition.Y = this.GraphicsDevice.Viewport.Height - Margin - this.BackTileTexture.Height - Margin - stringSize.Y;
                spriteBatch.DrawString(this.Font_CourierNew, BoardMessage, messagePosition, Color.Black);
            }
        }

        void DrawTiles()
        {
            Vector2 origin = new Vector2(0, 0);
            foreach (var TTI in this.TilesToDraw)
            {
                //Color TileColor;
                //if (TTI.MouseOvered) TileColor = this.SelectableTileColor_MouseOver;
                //else if (TTI.Highlighted) TileColor = this.SelectableTileColor_Highlighted;
                //else TileColor = Color.White;

                //spriteBatch.Draw(TTI.Texture, TTI.Position, null, TileColor, TTI.Rotation, origin, 1.0f, SpriteEffects.None, 0.0f);
                spriteBatch.Draw(TTI.Texture, TTI.Position, null, TTI.ShadeColor, TTI.Rotation, origin, 1.0f, SpriteEffects.None, 0.0f);
            }
            //spriteBatch.Draw(tileTexture, currentPosition, null, this.SelectableTileColor, angle, new Vector2(0, 0), scale, SpriteEffects.None, 0.0f);
        }

        void DrawTooltip()
        {
            if (tileToolTips && !String.IsNullOrEmpty(this.tooltipText))
            {
                var stringSize = this.Font_CourierNew.MeasureString(tooltipText);
                spriteBatch.Draw(this.tooltipBG, new Rectangle((int)this.tooltipPosition.X-1,(int)this.tooltipPosition.Y-1, (int)stringSize.X+2, (int)stringSize.Y+2), Color.White);
                spriteBatch.DrawString(Font_CourierNew, this.tooltipText, this.tooltipPosition, Color.DarkBlue);
            }
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            spriteBatch.Begin(SpriteSortMode.Immediate, BlendState.AlphaBlend);
            //spriteBatch.Begin(SpriteSortMode.FrontToBack, BlendState.AlphaBlend);

            // TODO: Add your drawing code here

            //If SpiteSortMode = Immediate, we have to draw the tiles first, else, we draw them last
            DrawTiles();
            DrawTooltip();
            DrawMessage();
            

            //DrawPlayer(BoardPosition.Bot, this.Player);
            //var currPlayer = this.MJGame.GetPlayerAfter(this.Player);
            //DrawPlayer(BoardPosition.Left, currPlayer);
            //currPlayer = this.MJGame.GetPlayerAfter(currPlayer);
            //DrawPlayer(BoardPosition.Top, currPlayer);
            //currPlayer = this.MJGame.GetPlayerAfter(currPlayer);
            //DrawPlayer(BoardPosition.Right, currPlayer);

            spriteBatch.End();
            base.Draw(gameTime);
        }
    }
}
